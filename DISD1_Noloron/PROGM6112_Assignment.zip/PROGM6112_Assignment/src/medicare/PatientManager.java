package medicare;

import java.util.ArrayList;
import java.util.Scanner;

public class PatientManager {
    private ArrayList<Patient> patientList = new ArrayList<>();


    public static boolean validatePatientId(String id) {
        if (!ValidationUtils.isValidSaId(id)) {
            return false;
        }
        return isValidLuhn(id);
    }


    private static boolean isValidLuhn(String id) {
        int sum = 0;
        boolean alternate = false;
        for (int i = id.length() - 1; i >= 0; i--) {
            int n = Integer.parseInt(id.substring(i, i + 1));
            if (alternate) {
                n *= 2;
                if (n > 9) {
                    n = (n % 10) + 1;
                }
            }
            sum += n;
            alternate = !alternate;
        }
        return (sum % 10 == 0);
    }

 
    public static String getGenderFromId(String id) {
        int genderDigits = Integer.parseInt(id.substring(6, 10));
        return (genderDigits >= 5000) ? "M" : "F";
    }

    public static int getAgeFromId(String id) {
        int birthYearShort = Integer.parseInt(id.substring(0, 2));
        int fullBirthYear = (birthYearShort <= 26) ? (2000 + birthYearShort) : (1900 + birthYearShort);
        return 2026 - fullBirthYear;
    }

    // CRUD Operations
    public boolean registerPatient(Patient patient) {
        for (Patient p : patientList) {
            if (p.getPatientId().equalsIgnoreCase(patient.getPatientId())) {
                System.out.println("Error: Patient ID " + patient.getPatientId() + " already exists!");
                return false;
            }
        }
        patientList.add(patient);
        System.out.println("Patient registered successfully.");
        return true;
    }

    public Patient searchPatient(String patientId) {
        for (Patient p : patientList) {
            if (p.getPatientId().equalsIgnoreCase(patientId)) {
                return p;
            }
        }
        return null;
    }

    public boolean updatePatient(String patientId, Scanner scanner) {
        Patient p = searchPatient(patientId);
        if (p == null) {
            System.out.println("Error: Patient with ID " + patientId + " not found.");
            return false;
        }

        System.out.println("\n--- Updating Details for ID: " + patientId + " ---");
        System.out.println("1. First Name\n2. Last Name\n3. Medical Condition");
        System.out.print("Select choice (1-3): ");

        int choice = getIntInput(scanner);

        switch (choice) {
            case 1:
                String fname = getStringInput(scanner, "Enter new First Name: ");
                while (!ValidationUtils.isValidName(fname)) {
                    System.out.println("Invalid name! Alphabetic characters only.");
                    fname = getStringInput(scanner, "Enter new First Name: ");
                }
                p.setFirstName(fname);
                break;

            case 2:
                String lname = getStringInput(scanner, "Enter new Last Name: ");
                while (!ValidationUtils.isValidName(lname)) {
                    System.out.println("Invalid name! Alphabetic characters only.");
                    lname = getStringInput(scanner, "Enter new Last Name: ");
                }
                p.setLastName(lname);
                break;

            case 3:
                String cond = getStringInput(scanner, "Enter new Medical Condition: ");
                p.setMedicalCondition(cond);
                break;

            default:
                System.out.println("Invalid choice option.");
                return false;
        }
        System.out.println("Patient details updated successfully.");
        return true;
    }

    public boolean deletePatient(String patientId) {
        Patient p = searchPatient(patientId);
        if (p != null) {
            patientList.remove(p);
            System.out.println("Patient " + patientId + " removed successfully.");
            return true;
        }
        System.out.println("Error: Patient not found.");
        return false;
    }

    public void displayAllPatients() {
        if (patientList.isEmpty()) {
            System.out.println("No patients currently registered.");
            return;
        }
        System.out.println("\n--- Registered Patients ---");
        for (Patient p : patientList) {
            p.displayDetails();
        }
    }

  
    public static int getIntInput(Scanner scanner) {
        while (true) {
            try {
                String input = scanner.nextLine().trim();
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.print("Invalid entry! Please enter a valid number: ");
            }
        }
    }

    public static String getStringInput(Scanner scanner, String prompt) {
        System.out.print(prompt);
        String input = scanner.nextLine().trim();
        while (input.isEmpty()) {
            System.out.print("Input cannot be blank. " + prompt);
            input = scanner.nextLine().trim();
        }
        return input;
    }

    public ArrayList<Patient> getPatientList() {
        return patientList;
    }
}