package medicare;

import java.util.ArrayList;

public class BedManager {
    private static final int WARD_ROWS = 4; // Wards A, B, C, D
    private static final int WARD_COLS = 5; // Beds 1 to 5 per ward
    private Inpatient[][] wardLayout = new Inpatient[WARD_ROWS][WARD_COLS];

    private char getWardLetter(int row) {
        return (char) ('A' + row);
    }

    // Displays bed layout and status  Occupied or Empty 
    public void displayWardLayout() {
        System.out.println("\n=========================================================================");
        System.out.println("                       HOSPITAL WARD BED                           ");
        System.out.println("=========================================================================");
        for (int r = 0; r < WARD_ROWS; r++) {
            System.out.print("WARD " + getWardLetter(r) + " | ");
            for (int c = 0; c < WARD_COLS; c++) {
                String bedCode = "W-" + getWardLetter(r) + (c + 1);
                if (wardLayout[r][c] != null) {
                    System.out.printf("%-7s:[Occupied]  ", bedCode);
                } else {
                    System.out.printf("%-7s:[  Empty ]  ", bedCode);
                }
            }
            System.out.println();
        }
        System.out.println("=========================================================================\n");
    }

    // Auto-allocates first open bed; prevents allocating multiple beds to one patient
    public String autoAllocateBed(Inpatient inpatient) {
        // Check if patient already holds a bed
        if (isPatientAlreadyBedded(inpatient.getPatientId())) {
            System.out.println("-> Error: Patient " + inpatient.getPatientId() + " already has a bed assigned (" + inpatient.getBedNumber() + ")!");
            return null;
        }

        for (int r = 0; r < WARD_ROWS; r++) {
            for (int c = 0; c < WARD_COLS; c++) {
                if (wardLayout[r][c] == null) {
                    String bedCode = "W-" + getWardLetter(r) + (c + 1);
                    wardLayout[r][c] = inpatient;
                    inpatient.setBedNumber(bedCode);
                    System.out.println("Successfully Auto-Allocated Bed " + bedCode + " to Patient " + inpatient.getPatientId());
                    return bedCode;
                }
            }
        }
        System.out.println("ALERT: Ward is fully OCCUPIED! No available beds. Consider releasing an existing bed.");
        return null;
    }

    // Manual Allocation with Single Bed Guarantee
    public boolean allocateBed(String bedCode, Inpatient inpatient) {
        if (isPatientAlreadyBedded(inpatient.getPatientId())) {
            System.out.println("Error: Patient " + inpatient.getPatientId() + " already has a bed assigned (" + inpatient.getBedNumber() + ")!");
            return false;
        }

        int[] pos = parseBedCode(bedCode);
        if (pos == null) {
            System.out.println("Error: Invalid bed code format. Use format like W-A1, W-B3.");
            return false;
        }

        int r = pos[0];
        int c = pos[1];

        if (wardLayout[r][c] != null) {
            System.out.println("Error: Bed " + bedCode + " is already [Occupied].");
            return false;
        }

        wardLayout[r][c] = inpatient;
        inpatient.setBedNumber(bedCode);
        System.out.println("Bed " + bedCode + " allocated to Patient " + inpatient.getPatientId() + " successfully.");
        return true;
    }

    public boolean releaseBed(String bedCode) {
        int[] pos = parseBedCode(bedCode);
        if (pos == null) {
            System.out.println("Error: Invalid bed code format.");
            return false;
        }

        int r = pos[0];
        int c = pos[1];

        if (wardLayout[r][c] == null) {
            System.out.println("Error: Bed " + bedCode + " is already empty.");
            return false;
        }

        Inpatient p = wardLayout[r][c];
        p.setBedNumber("Unassigned");
        wardLayout[r][c] = null;
        System.out.println("Bed " + bedCode + " released successfully.");
        return true;
    }

    private boolean isPatientAlreadyBedded(String patientId) {
        for (int r = 0; r < WARD_ROWS; r++) {
            for (int c = 0; c < WARD_COLS; c++) {
                if (wardLayout[r][c] != null && wardLayout[r][c].getPatientId().equalsIgnoreCase(patientId)) {
                    return true;
                }
            }
        }
        return false;
    }

    private int[] parseBedCode(String code) {
        try {
            String[] parts = code.toUpperCase().split("-");
            if (parts.length != 2) return null;

            char wardChar = parts[0].charAt(parts[0].length() - 1);
            int row = wardChar - 'A';
            int col = Integer.parseInt(parts[1]) - 1;

            if (row >= 0 && row < WARD_ROWS && col >= 0 && col < WARD_COLS) {
                return new int[]{row, col};
            }
        } catch (Exception e) {
            return null;
        }
        return null;
    }

    public void displayBedOccupancyReport() {
        int occupied = 0;
        int total = WARD_ROWS * WARD_COLS;

        for (int r = 0; r < WARD_ROWS; r++) {
            for (int c = 0; c < WARD_COLS; c++) {
                if (wardLayout[r][c] != null) occupied++;
            }
        }

        double percentage = ((double) occupied / total) * 100;
        System.out.println("\n--- BED OCCUPANCY REPORT ---");
        System.out.println("Total Beds    : " + total);
        System.out.println("Occupied Beds : " + occupied);
        System.out.println("Available Beds: " + (total - occupied));
        System.out.printf("Occupancy Rate: %.2f%%\n", percentage);
    }

    public void displaySortedPatientsById(ArrayList<Patient> list) {
        System.out.println("\n--- ALL PATIENTS ---");
        for (Patient p : list) {
            p.displayDetails();
        }
    }
}