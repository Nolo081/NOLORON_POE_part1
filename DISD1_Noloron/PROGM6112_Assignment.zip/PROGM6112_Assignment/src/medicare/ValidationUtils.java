package medicare;

import java.util.regex.Pattern;

public class ValidationUtils {

    private static final String SA_ID_REGEX = "^\\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\\d|3[01])\\d{4}[01][89]\\d$";
    private static final String NAME_REGEX = "^[a-zA-Z\\s-]{2,50}$";
    private static final String GENDER_REGEX = "^(?i)[MF]$";
    // Formatted for Ward Matrix codes like W-A1, W-B4, etc.
    private static final String BED_CODE_REGEX = "^(?i)W-[A-D][1-5]$";

    public static boolean isValidSaId(String id) {
        return id != null && Pattern.matches(SA_ID_REGEX, id);
    }

    public static boolean isValidName(String name) {
        return name != null && Pattern.matches(NAME_REGEX, name.trim());
    }

    public static boolean isValidGender(String gender) {
        return gender != null && Pattern.matches(GENDER_REGEX, gender.trim());
    }

    public static boolean isValidBedCode(String bedCode) {
        return bedCode != null && Pattern.matches(BED_CODE_REGEX, bedCode.trim());
    }
}