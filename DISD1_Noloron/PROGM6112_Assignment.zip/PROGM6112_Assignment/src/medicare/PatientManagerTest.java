package medicare;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PatientManagerTest {

    private PatientManager patientManager;
    private BedManager bedManager;

    private final String VALID_MALE_ID = "9001015800080";   // Male born 1990/01/01
    private final String VALID_FEMALE_ID = "9505050800088"; // Female born 1995/05/05

    @BeforeEach
    public void setUp() {
        patientManager = new PatientManager();
        bedManager = new BedManager();
    }

    // ---  Regex & SA ID Validation Tests ---

    @Test
    public void testValidSaIdValidation() {
        assertTrue(PatientManager.validatePatientId(VALID_MALE_ID), "Valid SA ID should return true.");
        assertTrue(PatientManager.validatePatientId(VALID_FEMALE_ID), "Valid SA ID should return true.");
    }

    @Test
    public void testInvalidSaIdFormat() {
        assertFalse(PatientManager.validatePatientId("12345"), "ID shorter than 13 digits should fail.");
        assertFalse(PatientManager.validatePatientId("900101580008A"), "ID containing letters should fail.");
        assertFalse(PatientManager.validatePatientId("9013325800080"), "Invalid month (13) should fail regex.");
    }

    @Test
    public void testInvalidSaIdLuhnChecksum() {
        // Correct 13-digit pattern, but corrupted last digit (checksum failure)
        assertFalse(PatientManager.validatePatientId("9001015800089"), "ID with failing Luhn checksum should return false.");
    }

    @Test
    public void testRegexNameValidation() {
        assertTrue(ValidationUtils.isValidName("John"), "Standard name should be valid.");
        assertTrue(ValidationUtils.isValidName("Mary-Jane"), "Hyphenated name should be valid.");
        assertFalse(ValidationUtils.isValidName("John123"), "Name with numbers should fail.");
        assertFalse(ValidationUtils.isValidName("A"), "Single character name should fail.");
    }

    @Test
    public void testRegexBedCodeValidation() {
        assertTrue(ValidationUtils.isValidBedCode("B01"), "B01 should be valid.");
        assertTrue(ValidationUtils.isValidBedCode("b20"), "Case-insensitive b20 should be valid.");
        assertFalse(ValidationUtils.isValidBedCode("B00"), "B00 is out of bounds.");
        assertFalse(ValidationUtils.isValidBedCode("B21"), "B21 is out of bounds (4x5 grid max is 20).");
    }

    @Test
    public void testAutoExtractAgeAndGender() {
        assertEquals("M", PatientManager.getGenderFromId(VALID_MALE_ID), "Gender digit >= 5000 should extract 'M'.");
        assertEquals("F", PatientManager.getGenderFromId(VALID_FEMALE_ID), "Gender digit < 5000 should extract 'F'.");
        
        // Born 1990 -> Age in 2026 should be 36
        assertEquals(36, PatientManager.getAgeFromId(VALID_MALE_ID), "Age calculation for 1990 birth year should equal 36.");
    }

    // ---  Patient Operations ---

    @Test
    public void testRegisterPatientSuccess() {
        Patient p = new Patient(VALID_MALE_ID, "Thabo", "Mokoena", 36, "M", "Flu", PatientCategory.OUTPATIENT);
        assertTrue(patientManager.registerPatient(p), "Registering a new patient should return true.");
        assertNotNull(patientManager.searchPatient(VALID_MALE_ID), "Registered patient should be retrievable.");
    }

    @Test
    public void testRegisterDuplicatePatientFails() {
        Patient p1 = new Patient(VALID_MALE_ID, "Thabo", "Mokoena", 36, "M", "Flu", PatientCategory.OUTPATIENT);
        Patient p2 = new Patient(VALID_MALE_ID, "Sipho", "Zuma", 36, "M", "Fever", PatientCategory.EMERGENCY);

        patientManager.registerPatient(p1);
        assertFalse(patientManager.registerPatient(p2), "Registering duplicate ID should return false.");
    }

    @Test
    public void testSearchNonExistentPatient() {
        assertNull(patientManager.searchPatient("0000000000000"), "Searching non-existent ID should return null.");
    }

    @Test
    public void testDeletePatient() {
        Patient p = new Patient(VALID_FEMALE_ID, "Lerato", "Khumalo", 31, "F", "Checkup", PatientCategory.OUTPATIENT);
        patientManager.registerPatient(p);

        assertTrue(patientManager.deletePatient(VALID_FEMALE_ID), "Deleting existing patient should return true.");
        assertNull(patientManager.searchPatient(VALID_FEMALE_ID), "Deleted patient should no longer be found.");
    }

    // ---  Bed Allocation Tests ---

    @Test
    public void testAllocateAndReleaseBed() {
        Inpatient inpatient = new Inpatient(VALID_MALE_ID, "Thabo", "Mokoena", 36, "M", "Surgery", "Ward A", "Unassigned");
        
        assertTrue(bedManager.allocateBed("B01", inpatient), "Allocating available bed B01 should succeed.");
        assertFalse(bedManager.allocateBed("B01", inpatient), "Allocating an already occupied bed should fail.");
        assertTrue(bedManager.releaseBed("B01"), "Releasing occupied bed B01 should succeed.");
    }
}