package medicare;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PatientManager patientManager = new PatientManager();
        BedManager bedManager = new BedManager();

        boolean running = true;

        while (running) {
            System.out.println("\n=== MEDICARE HOSPITAL Main menu ===");
            System.out.println("1. Register Patient");
            System.out.println("2. Search Patient");
            System.out.println("3. Update Patient Details");
            System.out.println("4. Delete Patient");
            System.out.println("5. Display Ward Bed Layout");
            System.out.println("6. Allocate Bed to Inpatient / Emergency");
            System.out.println("7. Release Bed");
            System.out.println("8. Generate Reports");
            System.out.println("9. Exit");
            System.out.print("Select an option (1-9): ");

            int choice = PatientManager.getIntInput(scanner);

            switch (choice) {
                case 1:
                    String id = "";
                    int age = 0;
                    String gender = "";
                    boolean idConfirmed = false;

                    while (!idConfirmed) {
                        id = PatientManager.getStringInput(scanner, "Enter 13-Digit SA ID Number: ");
                        while (!PatientManager.validatePatientId(id)) {
                            System.out.println("Invalid SA ID Number ");
                            id = PatientManager.getStringInput(scanner, "Re-enter 13-Digit SA ID Number: ");
                        }

                        age = PatientManager.getAgeFromId(id);
                        gender = PatientManager.getGenderFromId(id);

                        System.out.println("Calculated Age: " + age + " | Gender: " + (gender.equals("M") ? "Male" : "Female"));
                        String confirm = PatientManager.getStringInput(scanner, "Is this correct? (Y/N): ");
                        if (confirm.equalsIgnoreCase("Y")) {
                            idConfirmed = true;
                        }
                    }

                    String fname = PatientManager.getStringInput(scanner, "Enter First Name: ");
                    while (!ValidationUtils.isValidName(fname)) {
                        System.out.println("Invalid name! Letters only.");
                        fname = PatientManager.getStringInput(scanner, "Enter First Name: ");
                    }

                    String lname = PatientManager.getStringInput(scanner, "Enter Last Name: ");
                    while (!ValidationUtils.isValidName(lname)) {
                        System.out.println("Invalid name! Letters only.");
                        lname = PatientManager.getStringInput(scanner, "Enter Last Name: ");
                    }

                    String condition = PatientManager.getStringInput(scanner, "Enter Medical Condition: ");

                    System.out.println("Select Category:\n1. INPATIENT\n2. OUTPATIENT\n3. EMERGENCY");
                    System.out.print("Choice (1-3): ");
                    int catChoice = PatientManager.getIntInput(scanner);

                    if (catChoice == 1) { // INPATIENT
                        Inpatient inpatient = new Inpatient(id, fname, lname, age, gender, condition, "Ward A", "Unassigned");
                        if (patientManager.registerPatient(inpatient)) {
                            bedManager.autoAllocateBed(inpatient);
                        }
                    } else if (catChoice == 3) { // EMERGENCY (Immediate Bed Assignment)
                        System.out.println("-> EMERGENCY Patient detected! Allocating bed immediately...");
                        Inpatient emergencyPatient = new Inpatient(id, fname, lname, age, gender, condition, "Emergency Ward", "Unassigned");
                        if (patientManager.registerPatient(emergencyPatient)) {
                            bedManager.autoAllocateBed(emergencyPatient);
                        }
                    } else { // OUTPATIENT
                        Patient patient = new Patient(id, fname, lname, age, gender, condition, PatientCategory.OUTPATIENT);
                        patientManager.registerPatient(patient);
                    }
                    break;

                case 2:
                    String searchId = PatientManager.getStringInput(scanner, "Enter Patient ID: ");
                    Patient found = patientManager.searchPatient(searchId);
                    if (found != null) found.displayDetails();
                    else System.out.println("Patient not found.");
                    break;

                case 3:
                    String updateId = PatientManager.getStringInput(scanner, "Enter Patient ID: ");
                    patientManager.updatePatient(updateId, scanner);
                    break;

                case 4:
                    String deleteId = PatientManager.getStringInput(scanner, "Enter Patient ID: ");
                    patientManager.deletePatient(deleteId);
                    break;

                case 5:
                    bedManager.displayWardLayout();
                    break;

                case 6:
                    String allocId = PatientManager.getStringInput(scanner, "Enter Patient ID for bed allocation: ");
                    Patient p = patientManager.searchPatient(allocId);
                    if (p instanceof Inpatient) {
                        Inpatient inp = (Inpatient) p;
                        if (!inp.getBedNumber().equalsIgnoreCase("Unassigned")) {
                            System.out.println("-> Patient already holds Bed " + inp.getBedNumber() + "!");
                        } else {
                            bedManager.autoAllocateBed(inp);
                        }
                    } else {
                        System.out.println("Error: Outpatients cannot be assigned a ward bed.");
                    }
                    break;

                case 7:
                    String relBed = PatientManager.getStringInput(scanner, "Enter Bed Code to release (e.g., W-A1): ").toUpperCase();
                    bedManager.releaseBed(relBed);
                    break;

                case 8:
                    patientManager.displayAllPatients();
                    bedManager.displayBedOccupancyReport();
                    bedManager.displaySortedPatientsById(patientManager.getPatientList());
                    break;

                case 9:
                    running = false;
                    System.out.println("Exiting system. Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice. Select 1-9.");
            }
        }
        scanner.close();
    }
}