/**
 * 
 */
/**
 * 
 */
module PROGM6112_Assignment {
	requires junit;
	requires org.junit.jupiter.api;
}